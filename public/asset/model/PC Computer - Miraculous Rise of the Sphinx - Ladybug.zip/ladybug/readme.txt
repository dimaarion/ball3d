hair has to be coloured in manualy.

contains yoyo prop as well